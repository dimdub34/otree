from otree.api import Currency as c, currency_range
from ._builtin import Page, WaitPage
from .models import Constants


class Decision(Page):
    form_model = "player"
    form_fields = ["public_account"]


class Results(Page):
    pass


class Final(Page):
    def is_displayed(self):
        return self.round_number == Constants.num_rounds

    def vars_for_template(self):
        return {
            "final_payoff": self.player.cumulative_payoff.to_real_world_currency(
                self.session)
        }


class DecisionWait(WaitPage):
    wait_for_all_groups = True
    title_text = "Please wait ..."
    body_text = ""

    def after_all_players_arrive(self):
        for g in self.subsession.get_groups():
            g.compute_total_public_account()

        for p in self.subsession.get_players():
            p.compute_payoffs()


class ResultsWait(WaitPage):
    wait_for_all_groups = True
    title_text = "Please wait ..."
    body_text = ""


page_sequence = [
    Decision, DecisionWait,
    Results, ResultsWait,
    Final
]

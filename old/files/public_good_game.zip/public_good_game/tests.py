from otree.api import Currency as c, currency_range, Submission
from . import pages
from ._builtin import Bot
from .models import Constants
import random


class PlayerBot(Bot):
    def play_round(self):
        yield (
            pages.Decision,
            {"public_account": random.randint(0, Constants.endowment)}
        )
        yield (pages.Results)

        if self.round_number == Constants.num_rounds:
            yield Submission(pages.Final, check_html=False)

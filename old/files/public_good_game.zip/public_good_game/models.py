from otree.api import (
    models, widgets, BaseConstants, BaseSubsession, BaseGroup, BasePlayer,
    Currency as c, currency_range
)


author = 'D. Dubois'

doc = """
Public good game
"""


class Constants(BaseConstants):
    name_in_url = 'public_good_game'
    players_per_group = 2
    num_rounds = 2

    endowment = 20
    mpcr = 0.6


class Subsession(BaseSubsession):
    def creating_session(self):
        if self.round_number == 1:
            self.group_randomly()
        else:
            self.group_like_round(1)


class Group(BaseGroup):
    total_public_account = models.IntegerField()

    def compute_total_public_account(self):
        self.total_public_account = sum(
            [p.public_account for p in self.get_players()])


class Player(BasePlayer):
    private_account = models.IntegerField()
    public_account = models.IntegerField(
        min=0, max=Constants.endowment,
        label="Enter the number of tokens you place in the public account")
    public_account_payoff = models.CurrencyField()
    cumulative_payoff = models.CurrencyField()

    def compute_payoffs(self):
        self.private_account = Constants.endowment - self.public_account
        self.public_account_payoff = self.group.total_public_account * Constants.mpcr
        self.payoff = c(self.private_account) + self.public_account_payoff
        self.cumulative_payoff = sum(
            [p.payoff for p in self.in_previous_rounds()]) + self.payoff
